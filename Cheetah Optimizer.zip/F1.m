
function o = F1(K)

global Vin ;
global c ;
global N ;
global proj_len;
global Ag
global r_coil
global coil_outerdiameter
global V_IGBT
global M
global f
global x0
global coil_border
global coil_innerdiameter
global efficiency
global Velocity
global B_max
global I_max
global Vremaining

Vin=K(1);
c = K(2);
N = K(3);


%% projectile area and inner diameter of the coil which is related to the projectile outer diameter not to the projectile area
Ag=(35*0.5*6+5*0.5*5)/1000000; % prjectile area (it contains 35 laminations *0.5mm*6mm + 5 laminations *0.5mm*5mm)
coil_innerdiameter = 17/1000 ;% to make the projectile diameter constant, put the inner diameter of the coil as a given value
coil_border=2.5 ;%the border between the laminations and the coil

%% resistance calculations
proj_len=28;
wire_diameter=1.3; %1
no_ofturns_per_layer=floor(proj_len/wire_diameter);
res_per_m=13.17248/1000;%20.9428/1000
len=pi*(17+wire_diameter)*no_ofturns_per_layer;
for i=1:floor(N/no_ofturns_per_layer)
    len=len+pi*(17+i*wire_diameter*2)*floor(no_ofturns_per_layer);
end 
len=len+(N/no_ofturns_per_layer-floor(N/no_ofturns_per_layer))*no_ofturns_per_layer*pi*(17+i*wire_diameter*2);
r_coil=((len/1000)*res_per_m)+((1/60)*(c/0.0025)); %  ((1/60)*(c/0.0025)) this term is for the capacitor resistance

%% coil outer diameter calculation
coil_outerdiameter=coil_innerdiameter+((ceil(N/no_ofturns_per_layer)*wire_diameter*2)/1000);

%% Electrical Properties

V_IGBT=2.3;

%% Mechanical Properties
x0=0;
f = 0 ; % You can set external force as ZERO
M= 28.32;   % kg/m

sim("Model_isA_V13.slx");
%% velocity measure
n=length(measuringpoint);
for i=1:n
    if measuringpoint(i)~=0
        Velocity=u(i);
        Vremaining=Vrem(i);
        break
    end
end
n=length(B);
B_max=B(1);
for i=2:n
    if B(i)>B_max
        B_max=B(i);
    end
end
n=length(II);
I_max=II(1);
for i=2:n
    if II(i)>I_max
        I_max=II(i);
    end
end

%% objective function
% efficiency=((0.5*M*Velocity*Velocity/1000)/(0.5*c*Vin*Vin));
efficiency=(0.5*M*Velocity*Velocity/1000)/(0.5*c*((Vin*Vin)-(Vremaining*Vremaining)));

%Vel_diff=abs(Velocity_needed-Velocity);

o=(1/efficiency);
% fit = Velocity
if B_max> 1.8
    o=1000;
end
if I_max> 290
    o=100;
end
end

%  your function should have this K
%optioldsysPID.slx
%optiNewsysPID.slx